<div class="col-md-2 bg-primary text-white p-3" style="min-height:100vh;">
<h5>Student Panel</h5>
<hr>

<p>
<strong><?= htmlspecialchars($_SESSION['student_name']) ?></strong><br>
<small>PRN: <?= htmlspecialchars($_SESSION['student']) ?></small>
</p>

<hr>

<a href="dashboard.php" class="text-white d-block mb-2">Dashboard</a>
<a href="logout.php" class="text-white d-block">Logout</a>

</div>