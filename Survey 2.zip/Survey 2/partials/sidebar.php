<div class="col-md-2 bg-dark text-white p-3" style="min-height:100vh;">
<h5>Admin Panel</h5>
<hr>

<a href="dashboard.php" class="text-white d-block mb-2">Dashboard</a>

<a href="departments.php" class="text-white d-block mb-2">Departments</a>

<a href="semesters.php" class="text-white d-block mb-2">Semesters</a>

<a href="batches.php" class="text-white d-block mb-2">Batches</a>
<a href="students.php" class="text-white d-block mb-2">Students</a>
<a href="students_import.php" class="text-white d-block mb-2">Import Students</a>
<a href="subjects.php" class="text-white d-block mb-2">Subjects</a>

<a href="question_bank.php" class="text-white d-block mb-2">Question Bank</a>

<a href="templates.php" class="text-white d-block mb-2">Templates</a>

<a href="sessions.php" class="text-white d-block mb-2">Create Sessions</a>

<a href="sessions_manage.php" class="text-white d-block mb-2">Manage Sessions</a>

<a href="reports.php" class="text-white d-block mb-2">Reports</a>

<hr>

<a href="logout.php" class="text-white d-block">Logout</a>

</div>