<?php
require '../config.php';

if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit;
}

$session_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$batch_id   = $_SESSION['batch'];
$prn        = $_SESSION['student'];

if ($session_id <= 0) {
    die("Invalid Session");
}

/* Validate session belongs to student's batch and is active */
$check = $db->prepare("
    SELECT s.*, sub.name AS subject
    FROM sessions s
    JOIN subjects sub ON s.subject_id = sub.id
    WHERE s.id = ? AND s.batch_id = ? AND s.active = 1
");
$check->execute([$session_id, $batch_id]);
$session = $check->fetch(PDO::FETCH_ASSOC);

if (!$session) {
    die("Access Denied or Session Closed.");
}

/* Prevent duplicate submission */
$dup = $db->prepare("
    SELECT id FROM responses_master 
    WHERE prn = ? AND session_id = ?
");
$dup->execute([$prn, $session_id]);

if ($dup->fetch()) {
    header("Location: dashboard.php?msg=already");
    exit;
}

/* Fetch session questions */
$qstmt = $db->prepare("
    SELECT * FROM session_questions 
    WHERE session_id = ?
");
$qstmt->execute([$session_id]);
$questions = $qstmt->fetchAll(PDO::FETCH_ASSOC);

include '../partials/header.php';
?>

<div class="container-fluid">
<div class="row">

<?php include '../partials/student_sidebar.php'; ?>

<div class="col-md-10 p-4">

<h4><?= htmlspecialchars($session['subject']) ?> - Feedback</h4>
<hr>

<?php if(empty($questions)): ?>
<div class="alert alert-warning">
No questions available for this survey.
</div>
<?php else: ?>

<form method="post" action="submit.php">

<input type="hidden" name="session_id" value="<?= $session_id ?>">

<?php foreach($questions as $index => $row): ?>
<div class="mb-4 p-3 border rounded">

<p>
<strong>Q<?= $index + 1 ?>.</strong>
<?= htmlspecialchars($row['question']) ?>
</p>

<div>
<?php
$labels = [
    1 => "Poor",
    2 => "Fair",
    3 => "Good",
    4 => "Very Good",
    5 => "Excellent"
];
?>

<div class="d-flex flex-wrap gap-3 mt-2">
<?php foreach($labels as $value => $text): ?>
<label class="border rounded px-3 py-2">
<input type="radio"
       name="q<?= $row['id'] ?>"
       value="<?= $value ?>"
       required>
<strong><?= $value ?></strong>
<br>
<small><?= $text ?></small>
</label>
<?php endforeach; ?>
</div>
</div>

<?php if($row['allow_comment']): ?>
<textarea name="c<?= $row['id'] ?>"
          class="form-control mt-2"
          placeholder="Optional comment"></textarea>
<?php endif; ?>

</div>
<?php endforeach; ?>

<button class="btn btn-success">Submit Survey</button>

</form>

<?php endif; ?>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>