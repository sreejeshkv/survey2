<?php
require '../config.php';

if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit;
}

include '../partials/header.php';

$batch_id = $_SESSION['batch'];

$stmt = $db->prepare("
SELECT 
    s.id,
    sub.name AS subject,
    t.name AS template_name
FROM sessions s
JOIN subjects sub ON s.subject_id = sub.id
JOIN templates t ON s.template_id = t.id
WHERE s.batch_id = ? AND s.active = 1
");
$stmt->execute([$batch_id]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid">
<div class="row">

<?php include '../partials/student_sidebar.php'; ?>

<div class="col-md-10 p-4">

<h3>Available Surveys</h3>
<?php if(isset($_GET['msg']) && $_GET['msg']=='success'): ?>
<div class="alert alert-success">
Survey Submitted Successfully.
</div>
<?php endif; ?>

<?php if(isset($_GET['msg']) && $_GET['msg']=='already'): ?>
<div class="alert alert-warning">
You have already submitted this survey.
</div>
<?php endif; ?>
<?php if(empty($sessions)): ?>
<div class="alert alert-info">No active surveys available.</div>
<?php else: ?>
<ul class="list-group">
<?php foreach($sessions as $s): ?>
<li class="list-group-item d-flex justify-content-between align-items-center">
<strong><?= htmlspecialchars($s['subject']) ?></strong><br>
<small class="text-muted">
<?= htmlspecialchars($s['template_name']) ?>
</small><a href="take_survey.php?id=<?= $s['id'] ?>" class="btn btn-sm btn-primary">Take Survey</a>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>