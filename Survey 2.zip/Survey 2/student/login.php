<?php
require '../config.php';
include '../partials/header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

   $prn = trim($_POST['prn']);
$dob_input = trim($_POST['dob']);

/* Convert YYYY-MM-DD to DD-MM-YYYY */
$parts = explode('-', $dob_input);
$dob = $parts[2] . '-' . $parts[1] . '-' . $parts[0];

$stmt = $db->prepare("SELECT * FROM students WHERE prn=? AND dob=?");
 
$stmt->execute([$prn, $dob]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($student) {
        $_SESSION['student'] = $student['prn'];
		    $_SESSION['student_name'] = $student['name'];
        $_SESSION['batch'] = $student['batch_id'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid PRN or DOB";
    }
}
?>

<div class="container mt-5">
<h3>Student Login</h3>

<?php if(isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="post">
<input type="text" name="prn" class="form-control mb-3" placeholder="PRN" required>
<input type="date" name="dob" class="form-control mb-3" required>
<button class="btn btn-success">Login</button>
</form>

</div>

<?php include '../partials/footer.php'; ?>