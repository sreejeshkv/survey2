<?php
require '../config.php';

if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit;
}

$session_id = intval($_POST['session_id']);
$prn = $_SESSION['student'];

/* Prevent duplicate submission */
$check = $db->prepare("
    SELECT id FROM responses_master 
    WHERE prn=? AND session_id=?
");
$check->execute([$prn, $session_id]);

if ($check->fetch()) {
    header("Location: dashboard.php?msg=already");
    exit;
}

/* Insert master record */
$db->prepare("
    INSERT INTO responses_master(prn, session_id)
    VALUES(?,?)
")->execute([$prn, $session_id]);

$response_id = $db->lastInsertId();

/* Fetch questions */
$q = $db->prepare("
    SELECT id FROM session_questions 
    WHERE session_id=?
");
$q->execute([$session_id]);

foreach ($q as $row) {

    $score = $_POST['q'.$row['id']];
    $comment = $_POST['c'.$row['id']] ?? '';

    $db->prepare("
        INSERT INTO responses_detail(response_id, question_id, score, comment)
        VALUES(?,?,?,?)
    ")->execute([
        $response_id,
        $row['id'],
        $score,
        $comment
    ]);
}

/* Redirect with success message */
header("Location: dashboard.php?msg=success");
exit;