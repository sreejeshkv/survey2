<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Semesters</h3>

<form method="post">
<input class="form-control mb-2" name="name" placeholder="Semester Name" required>
<button class="btn btn-primary">Add</button>
</form>

<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
$db->prepare("INSERT INTO semesters(name) VALUES(?)")->execute([$_POST['name']]);
}

$rows=$db->query("SELECT * FROM semesters")->fetchAll(PDO::FETCH_ASSOC);
?>
<table class="table table-bordered mt-3">
<tr><th>ID</th><th>Name</th></tr>
<?php foreach($rows as $r): ?>
<tr><td><?= $r['id'] ?></td><td><?= $r['name'] ?></td></tr>
<?php endforeach; ?>
</table>
</div></div></div>
<?php include '../partials/footer.php'; ?>
