<?php
require '../config.php';
require_admin();
include '../partials/header.php';

/* ---------- Delete Student ---------- */
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    $db->prepare("DELETE FROM students WHERE id=?")->execute([$id]);
}

/* ---------- Fetch Batches ---------- */
$batches = $db->query("
SELECT b.id, d.name AS dept, s.name AS sem, b.academic_year
FROM batches b
JOIN departments d ON b.department_id = d.id
JOIN semesters s ON b.semester_id = s.id
")->fetchAll(PDO::FETCH_ASSOC);

$selected_batch = isset($_GET['batch']) ? intval($_GET['batch']) : 0;

/* ---------- Fetch Students ---------- */
if($selected_batch > 0){
    $stmt = $db->prepare("SELECT * FROM students WHERE batch_id=? ORDER BY prn");
    $stmt->execute([$selected_batch]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $students = [];
}
?>

<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>

<div class="col-md-10 p-4">

<h3>Student Management</h3>

<form method="get" class="mb-3">
<select name="batch" class="form-select" onchange="this.form.submit()">
<option value="">Select Batch</option>
<?php foreach($batches as $b): ?>
<option value="<?= $b['id'] ?>"
<?= $selected_batch == $b['id'] ? 'selected' : '' ?>>
<?= $b['dept'] ?> - <?= $b['sem'] ?> - <?= $b['academic_year'] ?>
</option>
<?php endforeach; ?>
</select>
</form>

<?php if($selected_batch > 0): ?>

<p><strong>Total Students:</strong> <?= count($students) ?></p>

<table class="table table-bordered">
<tr>
<th>ID</th>
<th>PRN</th>
<th>Name</th>
<th>DOB</th>
<th>Action</th>
</tr>

<?php foreach($students as $st): ?>
<tr>
<td><?= $st['id'] ?></td>
<td><?= htmlspecialchars($st['prn']) ?></td>
<td><?= htmlspecialchars($st['name']) ?></td>
<td><?= htmlspecialchars($st['dob']) ?></td>
<td>
<a href="?batch=<?= $selected_batch ?>&delete=<?= $st['id'] ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('Delete this student?')">
Delete
</a>
</td>
</tr>
<?php endforeach; ?>

</table>

<?php else: ?>
<div class="alert alert-info">Select a batch to view students.</div>
<?php endif; ?>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>