<?php
require '../config.php';
require_admin();
include '../partials/header.php';

/* ---------- Validate Template ID ---------- */
$template_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($template_id <= 0) {
    die("Invalid Template ID");
}

/* ---------- Fetch Template Name ---------- */
$tempStmt = $db->prepare("SELECT * FROM templates WHERE id=?");
$tempStmt->execute([$template_id]);
$template = $tempStmt->fetch(PDO::FETCH_ASSOC);

if (!$template) {
    die("Template Not Found");
}

/* ---------- Handle Form Submission ---------- */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Delete existing questions
    $db->prepare("DELETE FROM template_questions WHERE template_id=?")
       ->execute([$template_id]);

    if (isset($_POST['questions']) && is_array($_POST['questions'])) {

        $order = 1;

        foreach ($_POST['questions'] as $qid) {

            $db->prepare("INSERT INTO template_questions(template_id,question_id,q_order)
                          VALUES(?,?,?)")
               ->execute([$template_id, intval($qid), $order]);

            $order++;
        }

        $message = "Template Updated Successfully.";

    } else {

        $message = "No questions selected. Template saved empty.";
    }
}

/* ---------- Get All Questions ---------- */
$questions = $db->query("SELECT * FROM question_bank")
                ->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Get Selected Questions ---------- */
$selectedStmt = $db->prepare("SELECT question_id FROM template_questions WHERE template_id=?");
$selectedStmt->execute([$template_id]);
$selectedQuestions = $selectedStmt->fetchAll(PDO::FETCH_COLUMN);

?>

<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>

<div class="col-md-10 p-4">

<h3>Template Builder</h3>
<p><strong>Template:</strong> <?= htmlspecialchars($template['name']) ?></p>

<?php if(isset($message)): ?>
<div class="alert alert-info"><?= $message ?></div>
<?php endif; ?>

<form method="post">

<?php if(empty($questions)): ?>
<div class="alert alert-warning">No questions available in Question Bank.</div>
<?php else: ?>

<?php foreach($questions as $q): ?>
<div class="form-check mb-2">
    <input 
        type="checkbox"
        name="questions[]"
        value="<?= $q['id'] ?>"
        class="form-check-input"
        <?= in_array($q['id'], $selectedQuestions) ? 'checked' : '' ?>
    >
    <label class="form-check-label">
        <?= htmlspecialchars($q['question']) ?>
        (Weight: <?= $q['weight'] ?><?= $q['allow_comment'] ? ', Comment Allowed' : '' ?>)
    </label>
</div>
<?php endforeach; ?>

<button class="btn btn-primary mt-3">Save Template</button>

<?php endif; ?>

</form>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>