<?php
require '../config.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
    if($_POST['username']=='admin' && $_POST['password']=='admin123'){
        $_SESSION['admin']=1;
        header("Location: dashboard.php");
        exit;
    } else {
        $error="Invalid Login";
    }
}
?>
<?php include '../partials/header.php'; ?>
<div class="container mt-5">
<h3>Admin Login</h3>
<form method="post">
<input class="form-control mb-2" name="username" placeholder="Username">
<input type="password" class="form-control mb-2" name="password" placeholder="Password">
<button class="btn btn-primary">Login</button>
</form>
<?=isset($error)?'<div class="text-danger mt-2">'.$error.'</div>':''?>
</div>
<?php include '../partials/footer.php'; ?>
