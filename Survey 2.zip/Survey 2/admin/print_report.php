<?php
require '../config.php';
require_admin();

$session_id=$_GET['id'];

$info=$db->prepare("
SELECT d.name as dept,se.name as sem,b.academic_year,sub.name as subject
FROM sessions s
JOIN batches b ON s.batch_id=b.id
JOIN departments d ON b.department_id=d.id
JOIN semesters se ON b.semester_id=se.id
JOIN subjects sub ON s.subject_id=sub.id
WHERE s.id=?");
$info->execute([$session_id]);
$info=$info->fetch(PDO::FETCH_ASSOC);

$q=$db->prepare("SELECT * FROM session_questions WHERE session_id=?");
$q->execute([$session_id]);

$total_weight=0;
$total_score=0;
?>

<html>
<head>
<title>Print Report</title>
<style>
body{font-family:Arial;}
table{border-collapse:collapse;width:100%;}
th,td{border:1px solid #000;padding:6px;}
</style>
</head>
<body onload="window.print()">

<h3 style="text-align:center;">Faculty Evaluation Report</h3>

<p><strong>Department:</strong> <?= $info['dept'] ?></p>
<p><strong>Semester:</strong> <?= $info['sem'] ?></p>
<p><strong>Academic Year:</strong> <?= $info['academic_year'] ?></p>
<p><strong>Subject:</strong> <?= $info['subject'] ?></p>

<table>
<tr><th>Question</th><th>Average</th><th>Weight</th><th>Weighted</th></tr>

<?php foreach($q as $row):
$avgQ=$db->prepare("SELECT AVG(score) FROM responses_detail WHERE question_id=?");
$avgQ->execute([$row['id']]);
$avg=$avgQ->fetchColumn();
$avg=$avg?round($avg,2):0;

$weighted=$avg*$row['weight'];

$total_weight+=$row['weight'];
$total_score+=$weighted;
?>
<tr>
<td><?= $row['question'] ?></td>
<td><?= $avg ?></td>
<td><?= $row['weight'] ?></td>
<td><?= round($weighted,2) ?></td>
</tr>
<?php endforeach; ?>
</table>

<?php
$percentage=$total_weight?round(($total_score/(5*$total_weight))*100,2):0;
?>

<h4>Total Weighted Score: <?= $percentage ?> %</h4>

</body>
</html>
