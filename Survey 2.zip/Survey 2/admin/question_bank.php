<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid"><div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Question Bank</h3>

<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
$db->prepare("INSERT INTO question_bank(question,weight,allow_comment)
VALUES(?,?,?)")->execute([
$_POST['question'],
$_POST['weight'],
isset($_POST['allow_comment'])?1:0
]);
}
?>

<form method="post">
<textarea name="question" class="form-control mb-2" placeholder="Enter Question" required></textarea>
<input type="number" name="weight" class="form-control mb-2" value="1" min="1" required>
<div class="form-check mb-2">
<input type="checkbox" name="allow_comment" class="form-check-input">
<label class="form-check-label">Allow Comment</label>
</div>
<button class="btn btn-primary">Add Question</button>
</form>

<?php
$rows=$db->query("SELECT * FROM question_bank")->fetchAll(PDO::FETCH_ASSOC);
?>
<table class="table table-bordered mt-3">
<tr><th>ID</th><th>Question</th><th>Weight</th><th>Comment</th></tr>
<?php foreach($rows as $r): ?>
<tr>
<td><?= $r['id'] ?></td>
<td><?= $r['question'] ?></td>
<td><?= $r['weight'] ?></td>
<td><?= $r['allow_comment']?'Yes':'No' ?></td>
</tr>
<?php endforeach; ?>
</table>

</div></div></div>
<?php include '../partials/footer.php'; ?>
