<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h2>Admin Dashboard</h2>
<p>Phase 1 Core Framework Ready.</p>
</div>
</div>
</div>
<?php include '../partials/footer.php'; ?>
