<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid"><div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Session Reports</h3>

<?php
$sessions=$db->query("
SELECT s.id,d.name as dept,se.name as sem,b.academic_year,sub.name as subject
FROM sessions s
JOIN batches b ON s.batch_id=b.id
JOIN departments d ON b.department_id=d.id
JOIN semesters se ON b.semester_id=se.id
JOIN subjects sub ON s.subject_id=sub.id
")->fetchAll(PDO::FETCH_ASSOC);
?>

<table class="table table-bordered">
<tr>
<th>ID</th><th>Department</th><th>Semester</th>
<th>Academic Year</th><th>Subject</th><th>Action</th>
</tr>

<?php foreach($sessions as $s): ?>
<tr>
<td><?= $s['id'] ?></td>
<td><?= $s['dept'] ?></td>
<td><?= $s['sem'] ?></td>
<td><?= $s['academic_year'] ?></td>
<td><?= $s['subject'] ?></td>
<td>
<a class="btn btn-sm btn-primary"
href="report_view.php?id=<?= $s['id'] ?>">View</a>
<a class="btn btn-sm btn-success"
href="export_excel.php?id=<?= $s['id'] ?>">Excel</a>
<a class="btn btn-sm btn-secondary"
href="print_report.php?id=<?= $s['id'] ?>" target="_blank">Print</a>
</td>
</tr>
<?php endforeach; ?>

</table>

</div></div></div>
<?php include '../partials/footer.php'; ?>
