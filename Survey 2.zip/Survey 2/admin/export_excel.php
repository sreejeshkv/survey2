<?php
require '../config.php';
require_admin();

$session_id=$_GET['id'];

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_".$session_id.".xls");

echo "Question\tAverage\tWeight\tWeighted\n";

$q=$db->prepare("SELECT * FROM session_questions WHERE session_id=?");
$q->execute([$session_id]);

$total_weight=0;
$total_score=0;

foreach($q as $row){
$avgQ=$db->prepare("SELECT AVG(score) FROM responses_detail WHERE question_id=?");
$avgQ->execute([$row['id']]);
$avg=$avgQ->fetchColumn();
$avg=$avg?round($avg,2):0;

$weighted=$avg*$row['weight'];

$total_weight+=$row['weight'];
$total_score+=$weighted;

echo $row['question']."\t".$avg."\t".$row['weight']."\t".round($weighted,2)."\n";
}

$percentage=$total_weight?round(($total_score/(5*$total_weight))*100,2):0;
echo "\nTotal Score\t".$percentage."%";
?>
