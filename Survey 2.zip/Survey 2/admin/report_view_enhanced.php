<?php
require '../config.php';
require_admin();
include '../partials/header.php';

$session_id=$_GET['id'];

$total_responses=$db->prepare("SELECT COUNT(*) FROM responses_master WHERE session_id=?");
$total_responses->execute([$session_id]);
$total_responses=$total_responses->fetchColumn();

$q=$db->prepare("SELECT * FROM session_questions WHERE session_id=?");
$q->execute([$session_id]);

$total_weight=0;
$total_score=0;
?>

<div class="container mt-4">

<h4>Enhanced Report</h4>
<p><strong>Total Submissions:</strong> <?= $total_responses ?></p>

<table class="table table-bordered">
<tr><th>Question</th><th>Average</th><th>Weight</th><th>Weighted</th></tr>

<?php foreach($q as $row):
$avgQ=$db->prepare("SELECT AVG(score) FROM responses_detail WHERE question_id=?");
$avgQ->execute([$row['id']]);
$avg=$avgQ->fetchColumn();
$avg=$avg?round($avg,2):0;

$weighted=$avg*$row['weight'];

$total_weight+=$row['weight'];
$total_score+=$weighted;
?>
<tr>
<td><?= $row['question'] ?></td>
<td><?= $avg ?></td>
<td><?= $row['weight'] ?></td>
<td><?= round($weighted,2) ?></td>
</tr>

<?php
if($row['allow_comment']){
$comments=$db->prepare("SELECT comment FROM responses_detail WHERE question_id=? AND comment!=''");
$comments->execute([$row['id']]);
echo "<tr><td colspan='4'><strong>Comments:</strong><ul>";
foreach($comments as $c){
echo "<li>".$c['comment']."</li>";
}
echo "</ul></td></tr>";
}
?>

<?php endforeach; ?>
</table>

<?php
$percentage=$total_weight?round(($total_score/(5*$total_weight))*100,2):0;
?>

<h5>Total Weighted Score: <?= $percentage ?> %</h5>

</div>

<?php include '../partials/footer.php'; ?>
