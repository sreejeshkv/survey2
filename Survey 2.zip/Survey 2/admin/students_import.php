<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Import Students (CSV)</h3>

<?php
$batches = $db->query("
SELECT 
    b.id,
    d.name AS dept,
    s.name AS sem,
    b.academic_year
FROM batches b
JOIN departments d ON b.department_id = d.id
JOIN semesters s ON b.semester_id = s.id
ORDER BY d.name, s.name, b.academic_year
")->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['batch']) && isset($_FILES['csv'])){
$batch=$_POST['batch'];
$file=fopen($_FILES['csv']['tmp_name'],'r');
while(($row=fgetcsv($file))!==FALSE){
$db->prepare("INSERT OR IGNORE INTO students(prn,name,dob,batch_id)
VALUES(?,?,?,?)")->execute([$row[0],$row[1],$row[2],$batch]);
}
fclose($file);
echo "<div class='alert alert-success'>Imported Successfully</div>";
}
?>

<form method="post" enctype="multipart/form-data">
<select name="batch" class="form-select mb-3" required>
<option value="">Select Batch</option>
<?php foreach($batches as $b): ?>
<option value="<?= $b['id'] ?>">
<?= htmlspecialchars($b['dept']) ?> 
- <?= htmlspecialchars($b['sem']) ?> 
- <?= htmlspecialchars($b['academic_year']) ?>
</option>
<?php endforeach; ?>
</select>
<input type="file" name="csv" class="form-control mb-2" required>
<button class="btn btn-primary">Upload</button>
</form>

<p class="mt-3">CSV Format: PRN,Name,YYYY-MM-DD</p>

</div></div></div>
<?php include '../partials/footer.php'; ?>
