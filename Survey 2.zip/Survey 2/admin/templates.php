<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid"><div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Templates</h3>

<?php
if(isset($_POST['name'])){
$db->prepare("INSERT INTO templates(name) VALUES(?)")->execute([$_POST['name']]);
}

$temps=$db->query("SELECT * FROM templates")->fetchAll(PDO::FETCH_ASSOC);
?>

<form method="post">
<input name="name" class="form-control mb-2" placeholder="Template Name" required>
<button class="btn btn-primary">Create Template</button>
</form>

<ul class="mt-3">
<?php foreach($temps as $t): ?>
<li>
<?= $t['id'] ?> - <?= $t['name'] ?>
<a href="template_builder.php?id=<?= $t['id'] ?>">Build</a>
</li>
<?php endforeach; ?>
</ul>

</div></div></div>
<?php include '../partials/footer.php'; ?>
