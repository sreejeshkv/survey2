<?php
require '../config.php';
require_admin();
include '../partials/header.php';

$session_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($session_id <= 0) {
    die("Invalid Session");
}

/* Fetch Session Details */
$sessionStmt = $db->prepare("
SELECT 
    s.*,
    sub.name AS subject,
    t.name AS template_name,
    d.name AS dept,
    se.name AS semester,
    b.academic_year
FROM sessions s
JOIN subjects sub ON s.subject_id = sub.id
JOIN templates t ON s.template_id = t.id
JOIN batches b ON s.batch_id = b.id
JOIN departments d ON b.department_id = d.id
JOIN semesters se ON b.semester_id = se.id
WHERE s.id = ?
");
$sessionStmt->execute([$session_id]);
$session = $sessionStmt->fetch(PDO::FETCH_ASSOC);

if (!$session) {
    die("Session Not Found");
}

/* Total Responses */
$totalRespStmt = $db->prepare("
SELECT COUNT(*) FROM responses_master WHERE session_id=?
");
$totalRespStmt->execute([$session_id]);
$total_responses = $totalRespStmt->fetchColumn();

/* Total Eligible Students */
$totalStuStmt = $db->prepare("
SELECT COUNT(*) FROM students WHERE batch_id=?
");
$totalStuStmt->execute([$session['batch_id']]);
$total_students = $totalStuStmt->fetchColumn();

/* Response Percentage */
$response_percent = $total_students > 0
    ? round(($total_responses / $total_students) * 100, 2)
    : 0;

/* Fetch Questions */
$qStmt = $db->prepare("
SELECT * FROM session_questions WHERE session_id=?
");
$qStmt->execute([$session_id]);
$questions = $qStmt->fetchAll(PDO::FETCH_ASSOC);

$total_weight = 0;
$total_score  = 0;
?>

<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>

<div class="col-md-10 p-4">

<h4>Survey Report</h4>
<hr>

<p>
<strong>Department:</strong> <?= htmlspecialchars($session['dept']) ?><br>
<strong>Semester:</strong> <?= htmlspecialchars($session['semester']) ?><br>
<strong>Academic Year:</strong> <?= htmlspecialchars($session['academic_year']) ?><br>
<strong>Subject:</strong> <?= htmlspecialchars($session['subject']) ?><br>
<strong>Template:</strong> <?= htmlspecialchars($session['template_name']) ?>
</p>

<hr>

<p>
<strong>Total Eligible Students:</strong> <?= $total_students ?><br>
<strong>Total Responses:</strong> <?= $total_responses ?><br>
<strong>Response Percentage:</strong> <?= $response_percent ?> %
</p>

<hr>

<table class="table table-bordered table-striped text-center">

<tr>
<th rowspan="2" class="text-start">Question</th>
<th rowspan="2">Average</th>
<th colspan="5">
No. of Students Responded (Rating Level)
</th>
<th rowspan="2">Weight</th>
<th rowspan="2">Weighted Score</th>
</tr>

<tr>
<th>Poor (1)</th>
<th>Fair (2)</th>
<th>Good (3)</th>
<th>Very Good (4)</th>
<th>Excellent (5)</th>
</tr>

<?php foreach($questions as $row):

/* Average */
$avgStmt = $db->prepare("
SELECT AVG(score) FROM responses_detail WHERE question_id=?
");
$avgStmt->execute([$row['id']]);
$avg = $avgStmt->fetchColumn();
$avg = $avg ? round($avg,2) : 0;

/* Distribution */
$countStmt = $db->prepare("
SELECT score, COUNT(*) as cnt
FROM responses_detail
WHERE question_id=?
GROUP BY score
");
$countStmt->execute([$row['id']]);

$levels = [1=>0,2=>0,3=>0,4=>0,5=>0];

foreach($countStmt as $c){
    $levels[$c['score']] = $c['cnt'];
}

/* Weighted */
$weighted = $avg * $row['weight'];

$total_weight += $row['weight'];
$total_score  += $weighted;
?>

<tr>
<td class="text-start"><?= htmlspecialchars($row['question']) ?></td>
<td><?= $avg ?></td>
<td><?= $levels[1] ?></td>
<td><?= $levels[2] ?></td>
<td><?= $levels[3] ?></td>
<td><?= $levels[4] ?></td>
<td><?= $levels[5] ?></td>
<td><?= $row['weight'] ?></td>
<td><?= round($weighted,2) ?></td>
</tr>

<?php endforeach; ?>
</table>

<?php
$overall_percent = $total_weight > 0
    ? round(($total_score / (5 * $total_weight)) * 100, 2)
    : 0;
?>

<hr>

<h5>Overall Weighted Score: <?= $overall_percent ?> %</h5>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>