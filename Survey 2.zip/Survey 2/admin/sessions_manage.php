<?php
require '../config.php';
require_admin();
include '../partials/header.php';

if(isset($_GET['toggle'])){
$id=$_GET['toggle'];
$db->exec("UPDATE sessions SET active = CASE WHEN active=1 THEN 0 ELSE 1 END WHERE id=".$id);
}

$sessions=$db->query("
SELECT s.id,s.active,sub.name as subject,d.name as dept,se.name as sem,b.academic_year
FROM sessions s
JOIN batches b ON s.batch_id=b.id
JOIN departments d ON b.department_id=d.id
JOIN semesters se ON b.semester_id=se.id
JOIN subjects sub ON s.subject_id=sub.id
")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container-fluid"><div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">

<h3>Manage Sessions</h3>

<table class="table table-bordered">
<tr>
<th>ID</th><th>Dept</th><th>Sem</th><th>Year</th>
<th>Subject</th><th>Status</th><th>Action</th>
</tr>

<?php foreach($sessions as $s): ?>
<tr>
<td><?= $s['id'] ?></td>
<td><?= $s['dept'] ?></td>
<td><?= $s['sem'] ?></td>
<td><?= $s['academic_year'] ?></td>
<td><?= $s['subject'] ?></td>
<td><?= $s['active']?'Active':'Closed' ?></td>
<td>
<a class="btn btn-sm btn-warning"
href="?toggle=<?= $s['id'] ?>">
<?= $s['active']?'Close':'Activate' ?>
</a>
</td>
</tr>
<?php endforeach; ?>

</table>

</div></div></div>

<?php include '../partials/footer.php'; ?>
