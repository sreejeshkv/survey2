<?php
require '../config.php';
require_admin();
include '../partials/header.php';

/* ---------- Fetch Dropdown Data ---------- */

$batches = $db->query("
SELECT b.id, d.name AS dept, s.name AS sem, b.academic_year
FROM batches b
JOIN departments d ON b.department_id = d.id
JOIN semesters s ON b.semester_id = s.id
")->fetchAll(PDO::FETCH_ASSOC);

$subjects = $db->query("
SELECT subjects.id, subjects.name, d.name AS dept, s.name AS sem
FROM subjects
JOIN departments d ON subjects.department_id = d.id
JOIN semesters s ON subjects.semester_id = s.id
")->fetchAll(PDO::FETCH_ASSOC);

$templates = $db->query("SELECT * FROM templates")
                ->fetchAll(PDO::FETCH_ASSOC);

/* ---------- Handle Session Creation ---------- */

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $batch_id = intval($_POST['batch']);
    $subject_id = intval($_POST['subject']);
    $template_id = intval($_POST['template']);

    // Insert session
    $db->prepare("INSERT INTO sessions(batch_id, subject_id, template_id, active)
                  VALUES(?,?,?,1)")
       ->execute([$batch_id, $subject_id, $template_id]);

    $session_id = $db->lastInsertId();

    // Snapshot questions from template
    $qs = $db->prepare("
        SELECT qb.question, qb.weight, qb.allow_comment
        FROM template_questions tq
        JOIN question_bank qb ON tq.question_id = qb.id
        WHERE tq.template_id = ?
        ORDER BY tq.q_order
    ");
    $qs->execute([$template_id]);

    foreach ($qs as $q) {
        $db->prepare("
            INSERT INTO session_questions(session_id, question, weight, allow_comment)
            VALUES(?,?,?,?)
        ")->execute([
            $session_id,
            $q['question'],
            $q['weight'],
            $q['allow_comment']
        ]);
    }

    $message = "Survey Session Created Successfully.";
}
?>

<div class="container-fluid">
<div class="row">
<?php include '../partials/sidebar.php'; ?>

<div class="col-md-10 p-4">

<h3>Create Survey Session</h3>

<?php if(isset($message)): ?>
<div class="alert alert-success"><?= $message ?></div>
<?php endif; ?>

<form method="post">

<select name="batch" class="form-select mb-3" required>
<option value="">Select Batch</option>
<?php foreach($batches as $b): ?>
<option value="<?= $b['id'] ?>">
<?= $b['dept'] ?> - <?= $b['sem'] ?> - <?= $b['academic_year'] ?>
</option>
<?php endforeach; ?>
</select>

<select name="subject" class="form-select mb-3" required>
<option value="">Select Subject</option>
<?php foreach($subjects as $s): ?>
<option value="<?= $s['id'] ?>">
<?= $s['dept'] ?> - <?= $s['sem'] ?> - <?= $s['name'] ?>
</option>
<?php endforeach; ?>
</select>

<select name="template" class="form-select mb-3" required>
<option value="">Select Template</option>
<?php foreach($templates as $t): ?>
<option value="<?= $t['id'] ?>">
<?= htmlspecialchars($t['name']) ?>
</option>
<?php endforeach; ?>
</select>

<button class="btn btn-primary">Create Session</button>

</form>

</div>
</div>
</div>

<?php include '../partials/footer.php'; ?>