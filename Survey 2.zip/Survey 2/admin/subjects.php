<?php
require '../config.php';
require_admin();
include '../partials/header.php';
?>
<div class="container-fluid"><div class="row">
<?php include '../partials/sidebar.php'; ?>
<div class="col-md-10 p-4">
<h3>Subjects</h3>

<?php
$depts=$db->query("SELECT * FROM departments")->fetchAll(PDO::FETCH_ASSOC);
$sems=$db->query("SELECT * FROM semesters")->fetchAll(PDO::FETCH_ASSOC);

if($_SERVER['REQUEST_METHOD']=='POST'){
$db->prepare("INSERT INTO subjects(department_id,semester_id,code,name)
VALUES(?,?,?,?)")->execute([
$_POST['dept'],$_POST['sem'],$_POST['code'],$_POST['name']
]);
}
?>

<form method="post">
<select name="dept" class="form-select mb-2" required>
<option value="">Select Department</option>
<?php foreach($depts as $d): ?>
<option value="<?= $d['id'] ?>"><?= $d['name'] ?></option>
<?php endforeach; ?>
</select>

<select name="sem" class="form-select mb-2" required>
<option value="">Select Semester</option>
<?php foreach($sems as $s): ?>
<option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
<?php endforeach; ?>
</select>

<input name="code" class="form-control mb-2" placeholder="Subject Code" required>
<input name="name" class="form-control mb-2" placeholder="Subject Name" required>
<button class="btn btn-primary">Add Subject</button>
</form>

</div></div></div>
<?php include '../partials/footer.php'; ?>
